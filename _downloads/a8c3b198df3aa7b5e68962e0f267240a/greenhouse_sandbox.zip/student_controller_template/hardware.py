"""Hardware selection for the GHU-2 greenhouse.

Owner: <name>

Your team's Milestone 2 glazing choice and heater rating. The simulator and
the acceptance test both read this file, so the mission your controller flies
runs on the hardware you declare here. Choose from the hardware menu in the
Milestone 2 insulation activity and record the rationale in your report.
"""

# TODO: Replace None with your team's choices.
#   GLAZING:  "polycarbonate", "twin_wall", "aerogel", or "vacuum_panel"
#   HEATER_W: 2000 or 3000
GLAZING = None
HEATER_W = None
